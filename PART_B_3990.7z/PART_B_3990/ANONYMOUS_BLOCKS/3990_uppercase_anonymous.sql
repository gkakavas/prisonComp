DECLARE  
BEGIN
INSERT INTO CUSTOMER VALUES(default,'hj89','peter','ioannoy','sweeden','stokholmi','komp',64,459,'01-JUN-22 04.24.48.000000000 PM');
INSERT INTO CATEGORY VALUES('politeleiasmespa',140,2);
INSERT INTO FACILITY VALUES('tileorasi',1);
END;